// import { View, Text , } from 'react-native'
// import React from 'react'

// export default function DescribeCard() {
//   return (
//     <View style={{
//         display:'flex',
//         flexDirection:'row',
//         alignItems:'center',
//         backgroundColor:Colors.white,
//         padding:10,
//         margin:5,
//         borderRadius :15,
//         gap:10
//     }}>
//     <StarIcon size={20} color='#FBBF24' />
//     <View>
//         <Text style={{fontSize:16,
//             color:'grey'
//         }}>
//           {data?.rating} 
//         </Text>
//     </View>
//     </View>
//   )
// }