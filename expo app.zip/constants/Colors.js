export default {
    primaryColor: '#2d10d6',
    bgColor: '#F4F4F4',
    black: '#27283a',
    white: '#FFFFFF',
  }